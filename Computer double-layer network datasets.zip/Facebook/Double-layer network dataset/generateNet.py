import os
import pandas as pd
import networkx as nx

output_dir = "Facebook_net/out"
os.makedirs(output_dir, exist_ok=True)


def read_edges(filename, main_node):
    """读取边并添加主节点连接"""
    edges = []
    nodes = set()
    with open(filename, 'r') as f:
        for line in f:
            if line.strip():
                u, v = map(int, line.strip().split())
                edges.append((u, v))
                nodes.update([u, v])

    # 添加主节点及连接
    nodes.add(main_node)
    for node in nodes:
        if node != main_node:
            edges.append((main_node, node))

    unique_edges = list({tuple(sorted(edge)) for edge in edges})
    return unique_edges, sorted(nodes)


def build_adjacency_matrix(edges, nodes):
    """构建邻接矩阵"""
    n = len(nodes)
    node_index = {node: idx for idx, node in enumerate(nodes)}
    matrix = [[0] * n for _ in range(n)]
    for u, v in edges:
        i, j = node_index[u], node_index[v]
        matrix[i][j] = matrix[j][i] = 1
    return matrix


def save_interlayer_matrix(layer0_nodes, layer348_nodes, inter_edges, filename):
    """保存层间邻接矩阵（非对称）"""
    # 创建映射
    layer0_index = {node: idx for idx, node in enumerate(layer0_nodes)}
    layer348_index = {node: idx for idx, node in enumerate(layer348_nodes)}

    # 初始化矩阵
    matrix = [[0] * len(layer348_nodes) for _ in range(len(layer0_nodes))]

    # 填充连接
    for u, v in inter_edges:
        if u in layer0_index and v in layer348_index:
            i = layer0_index[u]
            j = layer348_index[v]
            matrix[i][j] = 1
        elif v in layer0_index and u in layer348_index:
            i = layer0_index[v]
            j = layer348_index[u]
            matrix[i][j] = 1

    # 转换为DataFrame
    df = pd.DataFrame(
        matrix,
        index=layer0_nodes,
        columns=layer348_nodes
    )

    # 保存Excel
    path = os.path.join(output_dir, filename)
    with pd.ExcelWriter(path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='InterLayer_Adjacency')


# ---------------------- 主流程 ----------------------
# 1. 处理层0（主节点0）
layer0_edges, layer0_nodes = read_edges('Facebook_net/input/0.txt', main_node=0)
layer0_matrix = build_adjacency_matrix(layer0_edges, layer0_nodes)

# 2. 处理层348（主节点348）
layer348_edges, layer348_nodes = read_edges('Facebook_net/input/348.txt', main_node=348)
layer348_matrix = build_adjacency_matrix(layer348_edges, layer348_nodes)

# 3. 处理层间连接
inter_edges = []
with open('Facebook_net/input/facebook_combined.txt', 'r') as f:
    for line in f:
        if line.strip():
            u, v = map(int, line.strip().split())
            if (u in layer0_nodes and v in layer348_nodes) or \
                    (v in layer0_nodes and u in layer348_nodes):
                inter_edges.append((u, v))

# 4. 保存所有结果
pd.DataFrame(layer0_nodes).to_csv(os.path.join(output_dir, 'layer0_nodes.csv'), index=False, header=False)
pd.DataFrame(layer0_matrix, index=layer0_nodes, columns=layer0_nodes).to_excel(
    os.path.join(output_dir, 'layer0_adjacency.xlsx')
)

pd.DataFrame(layer348_nodes).to_csv(os.path.join(output_dir, 'layer348_nodes.csv'), index=False, header=False)
pd.DataFrame(layer348_matrix, index=layer348_nodes, columns=layer348_nodes).to_excel(
    os.path.join(output_dir, 'layer348_adjacency.xlsx')
)

save_interlayer_matrix(layer0_nodes, layer348_nodes, inter_edges, 'inter_layer_adjacency.xlsx')

# 5. 输出统计
print(f"层0节点数: {len(layer0_nodes)}")
print(f"层348节点数: {len(layer348_nodes)}")
print(f"层间连接数: {len(inter_edges)}")
print(f"输出文件位置: {os.path.abspath(output_dir)}")