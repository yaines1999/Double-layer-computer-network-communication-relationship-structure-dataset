import csv
import os
from collections import defaultdict


def generate_department_reports():
    """生成部门成员详细文档"""
    input_file = 'input/email-Eu-core-department-labels.txt'
    output_csv = 'output/department_members.csv'
    output_txt = 'output/department_report.txt'

    # 创建输出目录
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)

    # 数据结构：存储部门与成员的映射
    departments = defaultdict(list)

    try:
        # 读取原始数据
        with open(input_file, 'r') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue

                # 解析数据
                try:
                    user_id, dept_id = map(int, line.split())
                    departments[dept_id].append(user_id)
                except (ValueError, IndexError):
                    print(f"警告：跳过格式错误行 #{line_num}")

        # 生成CSV文件（详细记录）
        with open(output_csv, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['DepartmentID', 'UserID'])
            for dept_id in sorted(departments):
                for user_id in sorted(departments[dept_id]):
                    writer.writerow([dept_id, user_id])

        # 生成文本报告（带统计信息）
        with open(output_txt, 'w') as txtfile:
            txtfile.write("部门成员详细报告\n")
            txtfile.write("=" * 40 + "\n\n")

            for dept_id in sorted(departments):
                members = sorted(departments[dept_id])
                txtfile.write(f"部门ID: {dept_id}\n")
                txtfile.write(f"成员数量: {len(members)}\n")
                txtfile.write("成员列表:\n")

                # 分块写入避免内存问题
                chunk_size = 50  # 每50个ID换行
                for i in range(0, len(members), chunk_size):
                    line = ", ".join(map(str, members[i:i + chunk_size]))
                    txtfile.write(line + ",\n")

                txtfile.write("\n" + "-" * 40 + "\n")

        print(f"CSV文件已生成：{os.path.abspath(output_csv)}")
        print(f"文本报告已生成：{os.path.abspath(output_txt)}")

    except FileNotFoundError:
        print(f"错误：输入文件 {input_file} 不存在")
    except Exception as e:
        print(f"处理过程中发生错误：{str(e)}")


if __name__ == "__main__":
    generate_department_reports()