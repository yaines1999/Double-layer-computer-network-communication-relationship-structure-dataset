# 输入和输出文件路径
input_file = 'input/email-Eu-core.txt'
output_file = 'output/email-Eu-core.txt'

with open(input_file, 'r') as f_in, open(output_file, 'w') as f_out:
    for line in f_in:
        # 去除行尾换行符并按空格分割列
        parts = line.strip().split()
        if len(parts) >= 2:
            # 处理两列并重新组合
            col1 = int(parts[0]) + 1
            col2 = int(parts[1]) + 1
            new_line = f"{col1} {col2}\n"
            f_out.write(new_line)
        else:
            # 保留无法处理的行（可选）
            f_out.write(line)