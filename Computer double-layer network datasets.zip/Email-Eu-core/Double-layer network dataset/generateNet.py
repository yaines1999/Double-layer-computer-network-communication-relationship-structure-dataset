import pandas as pd
import numpy as np
from collections import defaultdict

# 读取数据
connections = pd.read_csv('output/email-Eu-core.txt', sep=' ', header=None, names=['node1', 'node2'])
departments = pd.read_csv('output/email-Eu-core-department-labels.txt', sep=' ', header=None, names=['node', 'dept'])

# 提取部门4和14的节点
dept4_nodes = departments[departments['dept'] == 4]['node'].values
dept14_nodes = departments[departments['dept'] == 14]['node'].values

# 创建节点到索引的映射
node_to_idx_A = {node: idx for idx, node in enumerate(sorted(dept4_nodes))}
node_to_idx_B = {node: idx for idx, node in enumerate(sorted(dept14_nodes))}

N = len(dept4_nodes)
M = len(dept14_nodes)

# 初始化邻接矩阵（对角线保持为0）
A = np.zeros((N, N), dtype=int)
B = np.zeros((M, M), dtype=int)
C = np.zeros((N, M), dtype=int)

# 处理所有连接（跳过节点自身的连接）
for _, row in connections.iterrows():
    node1, node2 = row['node1'], row['node2']

    # 跳过自环连接（节点连接自身）
    if node1 == node2:
        continue

    # 两个节点都在部门4
    if node1 in node_to_idx_A and node2 in node_to_idx_A:
        i, j = node_to_idx_A[node1], node_to_idx_A[node2]
        A[i][j] = 1
        A[j][i] = 1  # 无向图，对称矩阵

    # 两个节点都在部门14
    elif node1 in node_to_idx_B and node2 in node_to_idx_B:
        i, j = node_to_idx_B[node1], node_to_idx_B[node2]
        B[i][j] = 1
        B[j][i] = 1  # 无向图，对称矩阵

    # 跨部门连接（部门4->部门14）
    elif node1 in node_to_idx_A and node2 in node_to_idx_B:
        i, j = node_to_idx_A[node1], node_to_idx_B[node2]
        C[i][j] = 1

    # 跨部门连接（部门14->部门4）
    elif node1 in node_to_idx_B and node2 in node_to_idx_A:
        i, j = node_to_idx_B[node1], node_to_idx_A[node2]
        C[j][i] = 1  # 注意这里索引顺序


# 计算统计信息
def calculate_stats(matrix, name):
    stats = {
        'Network': name,
        'Number of Nodes': matrix.shape[0],
        'Number of Edges': np.sum(matrix) // 2 if matrix.shape[0] == matrix.shape[1] else np.sum(matrix),
        'Density': None,
        'Average Degree': None
    }

    if matrix.shape[0] == matrix.shape[1]:  # 对于方阵(层内连接)
        possible_edges = matrix.shape[0] * (matrix.shape[0] - 1) / 2
        stats['Density'] = stats['Number of Edges'] / possible_edges if possible_edges > 0 else 0
        stats['Average Degree'] = 2 * stats['Number of Edges'] / stats['Number of Nodes'] if stats[
                                                                                                 'Number of Nodes'] > 0 else 0
    else:  # 对于非方阵(层间连接)
        possible_edges = matrix.shape[0] * matrix.shape[1]
        stats['Density'] = stats['Number of Edges'] / possible_edges if possible_edges > 0 else 0
        stats['Average Degree'] = None  # 层间连接无平均度数概念

    return stats


stats_A = calculate_stats(A, 'A (Dept 4 Internal)')
stats_B = calculate_stats(B, 'B (Dept 14 Internal)')
stats_C = calculate_stats(C, 'C (Dept 4-14 Inter)')

# 创建DataFrame输出到Excel
with pd.ExcelWriter('network_analysis.xlsx') as writer:
    # 邻接矩阵
    pd.DataFrame(A, index=sorted(dept4_nodes), columns=sorted(dept4_nodes)).to_excel(writer, sheet_name='A_Matrix')
    pd.DataFrame(B, index=sorted(dept14_nodes), columns=sorted(dept14_nodes)).to_excel(writer, sheet_name='B_Matrix')
    pd.DataFrame(C, index=sorted(dept4_nodes), columns=sorted(dept14_nodes)).to_excel(writer, sheet_name='C_Matrix')

    # 统计信息
    stats_df = pd.DataFrame([stats_A, stats_B, stats_C])
    stats_df.to_excel(writer, sheet_name='Statistics', index=False)

    # 节点列表
    pd.DataFrame({'Department 4 Nodes': sorted(dept4_nodes)}).to_excel(writer, sheet_name='Dept4_Nodes')
    pd.DataFrame({'Department 14 Nodes': sorted(dept14_nodes)}).to_excel(writer, sheet_name='Dept14_Nodes')

print("分析完成，结果已保存到network_analysis.xlsx")